# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fixtures\auth.setup.ts >> authenticate as admin
- Location: e2e\fixtures\auth.setup.ts:8:1

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\KOROS\AppData\Local\Temp\cursor-sandbox-cache\19f416749617cec785c1a79dcad3be5b\playwright\chromium_headless_shell-1234\chrome-headless-shell-win64\chrome-headless-shell.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```